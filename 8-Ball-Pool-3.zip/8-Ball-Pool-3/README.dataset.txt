# 8-Ball Pool > 2025-01-24 10:43am
https://universe.roboflow.com/bachelorthesis/8-ball-pool-l530o

Provided by a Roboflow user
License: CC BY 4.0

